<div class="container-fluid">
	<div class="bg-lighter trending-products">
		<div class="heading heading-flex mb-3">
			<div class="heading-left">
				<h2 class="title">All Products</h2>
				<!-- End .title -->
			</div>
			<!-- End .heading-left -->

			<div class="heading-right">
				<ul class="nav nav-pills justify-content-center" role="tablist">
					<li class="nav-item">
						<a class="nav-link active" id="trending-all-link" data-toggle="tab" href="#trending-all-tab" role="tab" aria-controls="trending-all-tab" aria-selected="true">All</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="trending-elec-link" data-toggle="tab" href="#trending-elec-tab" role="tab" aria-controls="trending-elec-tab" aria-selected="false">Electronics</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="trending-furn-link" data-toggle="tab" href="#trending-furn-tab" role="tab" aria-controls="trending-furn-tab" aria-selected="false">Furniture</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="trending-cloth-link" data-toggle="tab" href="#trending-cloth-tab" role="tab" aria-controls="trending-cloth-tab" aria-selected="false">Clothes</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="trending-acc-link" data-toggle="tab" href="#trending-acc-tab" role="tab" aria-controls="trending-acc-tab" aria-selected="false">Accessories</a>
					</li>
				</ul>
			</div>
			<!-- End .heading-right -->
		</div>
		<!-- End .heading -->

		<div class="tab-content tab-content-carousel">
			<div class="tab-pane p-0 fade show active" id="trending-all-tab" role="tabpanel" aria-labelledby="trending-all-link">
				<div class="owl-carousel owl-simple carousel-equal-height carousel-with-shadow" data-toggle="owl" data-owl-options='{
								"nav": false, 
								"dots": true,
								"margin": 20,
								"loop": false,
								"responsive": {
									"0": {
										"items":1
									},
									"480": {
										"items":2
									},
									"768": {
										"items":3
									},
									"992": {
										"items":4
									},
									"1200": {
										"items":3,
										"nav": true
									},
									"1600": {
										"items":5,
										"nav": true
									}
								}
							}'>
					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-1.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Butler Stool Ladder</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$251.99</span>
								<span class="old-price">Was $290.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 2 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-2.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-countdown" data-until="+55h" data-relative="true" data-labels-short="true"></div>
							<!-- End .product-countdown -->

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Bose - SoundSport wireless headphones</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$179.99</span>
								<span class="old-price">Was $199.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #69b4ff"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #ff887f"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #333333"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-3.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Can 2-Seater Sofa frame charcoal</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$3,050.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 60%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 8 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #b58555"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #93a6b0"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-4.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Clothes</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Tan suede biker jacket</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$240.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-5.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Sony - Class LED 2160p Smart <br />4K Ultra HD</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,699.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 10 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-6.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Laptops</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">MacBook Pro 13" Display, i5</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,199.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->
				</div>
				<!-- End .owl-carousel -->
			</div>
			<!-- .End .tab-pane -->
			<div class="tab-pane p-0 fade" id="trending-elec-tab" role="tabpanel" aria-labelledby="trending-elec-link">
				<div class="owl-carousel owl-simple carousel-equal-height carousel-with-shadow" data-toggle="owl" data-owl-options='{
								"nav": false, 
								"dots": true,
								"margin": 20,
								"loop": false,
								"responsive": {
									"0": {
										"items":1
									},
									"480": {
										"items":2
									},
									"768": {
										"items":3
									},
									"992": {
										"items":4
									},
									"1200": {
										"items":3,
										"nav": true
									},
									"1600": {
										"items":5,
										"nav": true
									}
								}
							}'>
					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-3.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Can 2-Seater Sofa frame charcoal</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$3,050.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 60%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 8 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #b58555"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #93a6b0"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-4.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Clothes</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Tan suede biker jacket</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$240.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-1.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Butler Stool Ladder</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$251.99</span>
								<span class="old-price">Was $290.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 2 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-2.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-countdown" data-until="+55h" data-relative="true" data-labels-short="true"></div>
							<!-- End .product-countdown -->

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Bose - SoundSport wireless headphones</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$179.99</span>
								<span class="old-price">Was $199.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #69b4ff"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #ff887f"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #333333"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-6.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Laptops</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">MacBook Pro 13" Display, i5</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,199.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-5.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Sony - Class LED 2160p Smart <br />4K Ultra HD</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,699.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 10 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->
				</div>
				<!-- End .owl-carousel -->
			</div>
			<!-- .End .tab-pane -->
			<div class="tab-pane p-0 fade" id="trending-furn-tab" role="tabpanel" aria-labelledby="trending-furn-link">
				<div class="owl-carousel owl-simple carousel-equal-height carousel-with-shadow" data-toggle="owl" data-owl-options='{
								"nav": false, 
								"dots": true,
								"margin": 20,
								"loop": false,
								"responsive": {
									"0": {
										"items":1
									},
									"480": {
										"items":2
									},
									"768": {
										"items":3
									},
									"992": {
										"items":4
									},
									"1200": {
										"items":3,
										"nav": true
									},
									"1600": {
										"items":5,
										"nav": true
									}
								}
							}'>
					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-6.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Laptops</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">MacBook Pro 13" Display, i5</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,199.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-2.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-countdown" data-until="+55h" data-relative="true" data-labels-short="true"></div>
							<!-- End .product-countdown -->

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Bose - SoundSport wireless headphones</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$179.99</span>
								<span class="old-price">Was $199.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #69b4ff"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #ff887f"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #333333"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-3.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Can 2-Seater Sofa frame charcoal</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$3,050.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 60%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 8 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #b58555"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #93a6b0"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-1.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Butler Stool Ladder</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$251.99</span>
								<span class="old-price">Was $290.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 2 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-5.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Sony - Class LED 2160p Smart <br />4K Ultra HD</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,699.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 10 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-4.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Clothes</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Tan suede biker jacket</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$240.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->
				</div>
				<!-- End .owl-carousel -->
			</div>
			<!-- .End .tab-pane -->
			<div class="tab-pane p-0 fade" id="trending-cloth-tab" role="tabpanel" aria-labelledby="trending-cloth-link">
				<div class="owl-carousel owl-simple carousel-equal-height carousel-with-shadow" data-toggle="owl" data-owl-options='{
								"nav": false, 
								"dots": true,
								"margin": 20,
								"loop": false,
								"responsive": {
									"0": {
										"items":1
									},
									"480": {
										"items":2
									},
									"768": {
										"items":3
									},
									"992": {
										"items":4
									},
									"1200": {
										"items":3,
										"nav": true
									},
									"1600": {
										"items":5,
										"nav": true
									}
								}
							}'>
					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-1.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Butler Stool Ladder</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$251.99</span>
								<span class="old-price">Was $290.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 2 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-5.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Sony - Class LED 2160p Smart <br />4K Ultra HD</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,699.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 10 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-6.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Laptops</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">MacBook Pro 13" Display, i5</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,199.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-2.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-countdown" data-until="+55h" data-relative="true" data-labels-short="true"></div>
							<!-- End .product-countdown -->

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Bose - SoundSport wireless headphones</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$179.99</span>
								<span class="old-price">Was $199.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #69b4ff"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #ff887f"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #333333"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-3.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Can 2-Seater Sofa frame charcoal</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$3,050.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 60%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 8 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #b58555"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #93a6b0"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->
				</div>
				<!-- End .owl-carousel -->
			</div>
			<!-- .End .tab-pane -->
			<div class="tab-pane p-0 fade" id="trending-acc-tab" role="tabpanel" aria-labelledby="trending-acc-link">
				<div class="owl-carousel owl-simple carousel-equal-height carousel-with-shadow" data-toggle="owl" data-owl-options='{
								"nav": false, 
								"dots": true,
								"margin": 20,
								"loop": false,
								"responsive": {
									"0": {
										"items":1
									},
									"480": {
										"items":2
									},
									"768": {
										"items":3
									},
									"992": {
										"items":4
									},
									"1200": {
										"items":3,
										"nav": true
									},
									"1600": {
										"items":5,
										"nav": true
									}
								}
							}'>
					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-4.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Clothes</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Tan suede biker jacket</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$240.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-3.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Furniture</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Can 2-Seater Sofa frame charcoal</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$3,050.00</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 60%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 8 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #b58555"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #93a6b0"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-sale">Sale</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-2.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-countdown" data-until="+55h" data-relative="true" data-labels-short="true"></div>
							<!-- End .product-countdown -->

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Bose - SoundSport wireless headphones</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">
								<span class="new-price">$179.99</span>
								<span class="old-price">Was $199.00</span>
							</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->

							<div class="product-nav product-nav-dots">
								<a href="#" class="active" style="background: #69b4ff"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #ff887f"><span class="sr-only">Color name</span></a>
								<a href="#" style="background: #333333"><span class="sr-only">Color name</span></a>
							</div>
							<!-- End .product-nav -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-5.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Electronics</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">Sony - Class LED 2160p Smart <br />4K Ultra HD</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,699.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 80%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 10 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->

					<div class="product text-center">
						<figure class="product-media">
							<span class="product-label label-top">Top</span>
							<a href="product.html">
								<img src="assets/images/demos/demo-14/products/product-6.jpg" alt="Product image" class="product-image" />
							</a>

							<div class="product-action-vertical">
								<a href="#" class="btn-product-icon btn-wishlist" title="Add to wishlist"><span>add to wishlist</span></a>
								<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
								<a href="#" class="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a>
							</div>
							<!-- End .product-action-vertical -->

							<div class="product-action">
								<a href="#" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
							</div>
							<!-- End .product-action -->
						</figure>
						<!-- End .product-media -->

						<div class="product-body">
							<div class="product-cat">
								<a href="#">Laptops</a>
							</div>
							<!-- End .product-cat -->
							<h3 class="product-title">
								<a href="product.html">MacBook Pro 13" Display, i5</a>
							</h3>
							<!-- End .product-title -->
							<div class="product-price">$1,199.99</div>
							<!-- End .product-price -->
							<div class="ratings-container">
								<div class="ratings">
									<div class="ratings-val" style="width: 100%"></div>
									<!-- End .ratings-val -->
								</div>
								<!-- End .ratings -->
								<span class="ratings-text">( 4 Reviews )</span>
							</div>
							<!-- End .rating-container -->
						</div>
						<!-- End .product-body -->
					</div>
					<!-- End .product -->
				</div>
				<!-- End .owl-carousel -->
			</div>
			<!-- .End .tab-pane -->
		</div>
		<!-- End .tab-content -->
	</div>
	<!-- End .bg-lighter -->
	<div class="row">
	</div>
	<!-- End .row -->
</div>
<!-- End .container-fluid -->